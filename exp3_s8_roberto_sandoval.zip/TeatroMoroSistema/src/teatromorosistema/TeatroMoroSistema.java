package teatromorosistema; 
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class TeatroMoroSistema {
    
    static final int CAPACIDAD_MAXIMA = 50; 
    static int numClientesActual = 0;
    static int numVentasActual = 0;
    static String[] CLIENTES_NOMBRES = new String[CAPACIDAD_MAXIMA];
    static int[] CLIENTES_TIPO = new int[CAPACIDAD_MAXIMA]; 
    static int[] VENTAS_CLIENTES_REF = new int[CAPACIDAD_MAXIMA]; 
    static int[] VENTAS_ASIENTOS_REF = new int[CAPACIDAD_MAXIMA]; 
    static int[] VENTAS_COSTO_FINAL = new int[CAPACIDAD_MAXIMA];
    static double[] VENTAS_DESCUENTO_APLICADO = new double[CAPACIDAD_MAXIMA];
    static int[] VENTAS_EVENTOS_REF = new int[CAPACIDAD_MAXIMA]; 
    static ArrayList<ArrayList<Object>> EVENTOS = new ArrayList<>();
    static ArrayList<Object[]> DESCUENTOS = new ArrayList<>(); 
    static final String NOMBRE_TEATRO = "Teatro Moro";
    static int ingresosTotales = 0;
    static Scanner scanner = new Scanner(System.in); 

    public static void main(String[] args) {
        inicializarSistema(); 
        
        int opcion;

        do {
            desplegarMenu();
            try {
                opcion = scanner.nextInt();
                scanner.nextLine();
            } catch (InputMismatchException e) {
                System.out.println("Entrada no válida. Por favor, ingrese un número.");
                scanner.nextLine(); 
                opcion = -1; 
            }

            switch (opcion) {
                case 1:
                    venderEntrada();
                    break;
                case 2:
                    visualizarResumen();
                    break;
                case 3:
                    anularVenta(); 
                    break; 
                case 4:
                    actualizarAsientos(); 
                    break;
                case 0:
                    System.out.println("Saliendo del programa. ¡Gracias por usar el sistema!");
                    break;
                default:
                    System.out.println("Opción no válida. Por favor, intente de nuevo.");
            }
        } while (opcion != 0);

        scanner.close();
    }
    
    private static void inicializarSistema() {
        for (int i = 0; i < CAPACIDAD_MAXIMA; i++) {
            VENTAS_CLIENTES_REF[i] = -1;
            VENTAS_ASIENTOS_REF[i] = -1;
            VENTAS_EVENTOS_REF[i] = -1;
        }

        DESCUENTOS.add(new Object[]{1, 0.10}); 
        DESCUENTOS.add(new Object[]{2, 0.15}); 
        int[] estadoInicial = new int[CAPACIDAD_MAXIMA]; 
        int[] precioBaseInicial = new int[CAPACIDAD_MAXIMA];
        for (int i = 0; i < CAPACIDAD_MAXIMA; i++) {
            estadoInicial[i] = 0;
            if (i < 10) precioBaseInicial[i] = 25000;
            else if (i < 30) precioBaseInicial[i] = 18000;
            else precioBaseInicial[i] = 12000;
        }
        
        ArrayList<Object> evento1 = new ArrayList<>();
        evento1.add(1); 
        evento1.add("Concierto de Verano"); 
        evento1.add(new ArrayList<int[]>()); 
        evento1.add(estadoInicial.clone());
        evento1.add(precioBaseInicial.clone());
        EVENTOS.add(evento1);

        ArrayList<Object> evento2 = new ArrayList<>();
        evento2.add(2); 
        evento2.add("Obra de Teatro 'Hamlet'"); 
        evento2.add(new ArrayList<int[]>()); 
        evento2.add(estadoInicial.clone()); 
        evento2.add(precioBaseInicial.clone());
        EVENTOS.add(evento2);

        ArrayList<Object> evento3 = new ArrayList<>();
        evento3.add(3); 
        evento3.add("Festival de Jazz"); 
        evento3.add(new ArrayList<int[]>()); 
        evento3.add(estadoInicial.clone()); 
        evento3.add(precioBaseInicial.clone());
        EVENTOS.add(evento3);
        
        System.out.println("Sistema del Teatro Moro inicializado. Capacidad: " + CAPACIDAD_MAXIMA + " asientos por evento.");
        System.out.println("Total de Eventos cargados: " + EVENTOS.size());
    }

    private static void desplegarMenu() {
        System.out.println("\n=== Sistema de Venta de Entradas - " + NOMBRE_TEATRO + " ===");
        System.out.println("1. Vender entrada");
        System.out.println("2. Visualizar resumen de ventas");
        System.out.println("3. Anular venta por ID"); 
        System.out.println("4. Actualizar estado de asientos");
        System.out.println("0. Salir");
        System.out.print("Seleccione una opción: ");
    }
    
    private static int seleccionarEvento() {
        System.out.println("\n--- Selección de Evento ---");
        
        for (int i = 0; i < EVENTOS.size(); i++) {
            ArrayList<Object> evento = EVENTOS.get(i);
            System.out.printf("%d. %s%n", i + 1, evento.get(1));
        }

        int opcionEvento = -1;
        int indiceSeleccionado = -1;
        boolean valido = false;
        
        while (!valido) {
            System.out.print("Elija el número del evento (1-" + EVENTOS.size() + "): ");
            try {
                opcionEvento = scanner.nextInt();
                scanner.nextLine();
                
                if (opcionEvento >= 1 && opcionEvento <= EVENTOS.size()) {
                    indiceSeleccionado = opcionEvento - 1;
                    valido = true;
                } else {
                    System.out.println("Opción no válida. Intente de nuevo.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Entrada no válida. Debe ingresar un número.");
                scanner.nextLine();
            }
        }
        return indiceSeleccionado;
    }

    private static int getEventIndexFromID(int eventID) {
        for (int i = 0; i < EVENTOS.size(); i++) {
            if ((Integer) EVENTOS.get(i).get(0) == eventID) {
                return i;
            }
        }
        return -1; 
    }
    
    private static int obtenerOregistrarCliente() {
        String nombre = "";
        boolean nombreValido = false;
        
        while (!nombreValido) {
            System.out.print("Ingrese nombre del cliente: ");
            nombre = scanner.nextLine().trim();
            
            if (nombre.matches("^[a-zA-ZáéíóúÁÉÍÓÚñÑ\\s]+$") && !nombre.isEmpty()) {
                nombreValido = true;
            } else {
                System.out.println("Error de Validación: El nombre solo debe contener letras y espacios.");
            }
        }
        
        for (int i = 0; i < numClientesActual; i++) {
            if (CLIENTES_NOMBRES[i].equalsIgnoreCase(nombre)) {
                System.out.println("Cliente existente encontrado (ID: " + i + ").");
                return i;
            }
        }
        
        if (numClientesActual >= CAPACIDAD_MAXIMA) {
             System.out.println("Error: Se ha alcanzado la capacidad máxima de clientes.");
             return -1;
        }

        int tipo = -1;
        boolean tipoValido = false;
        while (!tipoValido) {
            System.out.print("Tipo de cliente (1: Estudiante, 2: Tercera Edad, 0: General): ");
            try {
                tipo = scanner.nextInt();
                scanner.nextLine(); 

                if (tipo >= 0 && tipo <= 2) {
                    tipoValido = true;
                } else {
                    System.out.println("Tipo no válido. Por favor, ingrese 0, 1 o 2.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Entrada no válida. Debe ingresar un número (0, 1 o 2).");
                scanner.nextLine(); 
            }
        }

        CLIENTES_NOMBRES[numClientesActual] = nombre;
        CLIENTES_TIPO[numClientesActual] = tipo;
        System.out.println("Nuevo cliente registrado con ID: " + numClientesActual);
        return numClientesActual++;
    }
    
    private static double aplicarDescuento(int tipoCliente, int precioBase) {
        double descuento = 0.0;
        
        for (Object[] promocion : DESCUENTOS) {
            if ((Integer)promocion[0] == tipoCliente) {
                descuento = (Double)promocion[1];
                break;
            }
        }
        
        int costoFinal = (int) Math.round(precioBase * (1.0 - descuento));
        return costoFinal;
    }
    
    private static int buscarPrimerAsientoDisponible(int opcionUbicacion, int[] ASES_ESTADO_EVENTO) {
        int inicio = 0;
        int fin = 0;
        String categoria = "";

        switch (opcionUbicacion) {
            case 1: inicio = 0; fin = 10; categoria = "VIP"; break;
            case 2: inicio = 10; fin = 30; categoria = "Platea"; break;
            case 3: inicio = 30; fin = CAPACIDAD_MAXIMA; categoria = "Balcón"; break;
            default: return -1;
        }

        for (int i = inicio; i < fin; i++) {
            if (ASES_ESTADO_EVENTO[i] == 0) {
                return i; 
            }
        }

        System.out.println("Lo sentimos, no quedan asientos disponibles en la categoría " + categoria + ".");
        return -1;
    }

    private static int seleccionarYCargarAsiento(ArrayList<Object> eventoSeleccionado) {
        System.out.println("\n--- Asignación de Asiento (Automática) ---");
        int opcionUbicacion = -1;
        int asientoID = -1;
        
        int[] ASES_ESTADO_EVENTO = (int[]) eventoSeleccionado.get(3);
        
        while (asientoID == -1) {
            System.out.println("Categorías Disponibles:");
            System.out.println("1. VIP ($25.000)");
            System.out.println("2. Platea ($18.000)");
            System.out.println("3. Balcón ($12.000)");
            System.out.print("Elija la categoría (1-3): ");

            try {
                opcionUbicacion = scanner.nextInt();
                scanner.nextLine();
                
                if (opcionUbicacion < 1 || opcionUbicacion > 3) {
                    System.out.println("Opción no válida. Intente de nuevo.");
                    continue; 
                }
                
                asientoID = buscarPrimerAsientoDisponible(opcionUbicacion, ASES_ESTADO_EVENTO);
                
                if (asientoID != -1) {
                    System.out.println("Asiento: ID " + asientoID + ".");
                    return asientoID;
                }
                
            } catch (InputMismatchException e) {
                System.out.println("Entrada no válida. Debe ingresar un número.");
                scanner.nextLine();
            }
        }
        return -1;
    }

    private static void venderEntrada() {
        System.out.println("\n--- Proceso de Venta de Entradas ---");
        
        if (numVentasActual >= CAPACIDAD_MAXIMA) {
             System.out.println("Se alcanzó el límite de ventas.");
             return;
        }

        int eventoIndex = seleccionarEvento(); 
        if (eventoIndex == -1) return; 

        ArrayList<Object> eventoSeleccionado = EVENTOS.get(eventoIndex);
        int eventoID = (Integer) eventoSeleccionado.get(0);
        int clienteID = obtenerOregistrarCliente();
        if (clienteID == -1) return;
        int asientoID = seleccionarYCargarAsiento(eventoSeleccionado); 
        if (asientoID == -1) return; 
        int[] ASES_ESTADO_EVENTO = (int[]) eventoSeleccionado.get(3);
        int[] ASES_PRECIO_EVENTO = (int[]) eventoSeleccionado.get(4);
        int precioBase = ASES_PRECIO_EVENTO[asientoID];
        int tipoCliente = CLIENTES_TIPO[clienteID];
        int costoFinal = (int) aplicarDescuento(tipoCliente, precioBase);
        double descuentoAplicado = 1.0 - ((double)costoFinal / precioBase);
        
        VENTAS_CLIENTES_REF[numVentasActual] = clienteID;
        VENTAS_ASIENTOS_REF[numVentasActual] = asientoID;
        VENTAS_COSTO_FINAL[numVentasActual] = costoFinal;
        VENTAS_DESCUENTO_APLICADO[numVentasActual] = descuentoAplicado;
        VENTAS_EVENTOS_REF[numVentasActual] = eventoID;
        
        ASES_ESTADO_EVENTO[asientoID] = 1; 

        @SuppressWarnings("unchecked")
        ArrayList<int[]> listaVentasEvento = (ArrayList<int[]>) eventoSeleccionado.get(2);
        listaVentasEvento.add(new int[]{numVentasActual}); 
        
        ingresosTotales += costoFinal;
        numVentasActual++;
        
        System.out.println("\nVenta #" + (numVentasActual - 1) + " registrada con éxito!");
        System.out.println("   Evento: " + eventoSeleccionado.get(1));
        System.out.println("   Cliente: " + CLIENTES_NOMBRES[clienteID] + " | Asiento ID: " + asientoID);
        System.out.println("   Costo Final: $" + costoFinal + " (Descuento: " + (int)(descuentoAplicado * 100) + "%)");
    }

    private static void anularVenta() {
        System.out.println("\n--- Anulación de Venta ---");

        if (numVentasActual == 0 || ingresosTotales == 0) {
            System.out.println("No hay ventas activas registradas para anular.");
            return;
        }
        
        System.out.println("\n--- Resumen de Tickets Activos ---");
        boolean hayVentasActivas = false;
        for (int i = 0; i < numVentasActual; i++) {
            if (VENTAS_ASIENTOS_REF[i] != -1) {
                int eventID = VENTAS_EVENTOS_REF[i];
                int eventIndex = getEventIndexFromID(eventID);
                String eventName = (eventIndex != -1) ? (String) EVENTOS.get(eventIndex).get(1) : "Evento Desconocido";

                System.out.printf("ID Venta: %d | Asiento: %d | Cliente: %s | Evento: %s | Costo: $%d%n",
                                 i, 
                                 VENTAS_ASIENTOS_REF[i], 
                                 CLIENTES_NOMBRES[VENTAS_CLIENTES_REF[i]], 
                                 eventName, 
                                 VENTAS_COSTO_FINAL[i]);
                hayVentasActivas = true;
            }
        }
        
        if (!hayVentasActivas) {
            System.out.println("No se encontraron tickets activos para anular.");
            return;
        }
        System.out.println("------------------------------------");

        int idVenta = -1;
        boolean idValida = false;

        while (!idValida) {
            System.out.print("Ingrese el ID de la venta a anular: ");

            try {
                idVenta = scanner.nextInt();
                scanner.nextLine();

                if (idVenta < 0 || idVenta >= numVentasActual || VENTAS_ASIENTOS_REF[idVenta] == -1) {
                    System.out.println("ID de venta no válido, fuera de rango o ya anulado. Intente de nuevo.");
                } else {
                    idValida = true;
                }
            } catch (InputMismatchException e) {
                System.out.println("Entrada no válida. Debe ser un número.");
                scanner.nextLine();
            }
        }

        final int idVentaAnular = idVenta;

        int asientoLiberadoID = VENTAS_ASIENTOS_REF[idVenta];
        int costoAnulado = VENTAS_COSTO_FINAL[idVenta];
        String nombreCliente = CLIENTES_NOMBRES[VENTAS_CLIENTES_REF[idVenta]];

        int eventoIDAnular = VENTAS_EVENTOS_REF[idVenta];
        int eventoIndexAnular = getEventIndexFromID(eventoIDAnular);
        
        if (eventoIndexAnular == -1) {
            System.out.println("Error: No se pudo encontrar el evento asociado a esta venta.");
            return;
        }
        
        int[] ASES_ESTADO_EVENTO = (int[]) EVENTOS.get(eventoIndexAnular).get(3);

        ASES_ESTADO_EVENTO[asientoLiberadoID] = 0;
        
        ingresosTotales -= costoAnulado;
        
        VENTAS_CLIENTES_REF[idVenta] = -1;
        VENTAS_ASIENTOS_REF[idVenta] = -1;
        VENTAS_COSTO_FINAL[idVenta] = 0;
        VENTAS_DESCUENTO_APLICADO[idVenta] = 0.0;
        VENTAS_EVENTOS_REF[idVenta] = -1; 
        
        @SuppressWarnings("unchecked")
        ArrayList<int[]> listaVentasEvento = (ArrayList<int[]>) EVENTOS.get(eventoIndexAnular).get(2);
        
        listaVentasEvento.removeIf(ref -> ref[0] == idVentaAnular); 

        System.out.println("\nVenta #" + idVenta + " ANULADA con éxito.");
        System.out.println("   Evento: " + EVENTOS.get(eventoIndexAnular).get(1));
        System.out.println("   Cliente: " + nombreCliente);
        System.out.println("   Asiento ID " + asientoLiberadoID + " liberado en el evento.");
        System.out.println("   Ingresos ajustados en: -$" + costoAnulado);
    }
    
    private static void visualizarResumen() {
        System.out.println("\n--- Resumen de Ventas y Eventos ---");
        
        System.out.println("Total de Ventas Registradas (Histórico, incluyendo anuladas): " + numVentasActual);
        
        int ventasActivas = 0;
        for (int i = 0; i < numVentasActual; i++) {
            if (VENTAS_ASIENTOS_REF[i] != -1) {
                ventasActivas++;
            }
        }
        System.out.println("Total de Tickets Activos: " + ventasActivas);
        System.out.println("Ingresos Totales (Neto): $" + ingresosTotales);
        System.out.println("Clientes Registrados: " + numClientesActual);
        
        System.out.println("\n--- Detalle por Evento ---");
        int totalOcupados = 0;
        for (ArrayList<Object> evento : EVENTOS) {
            String nombreEvento = (String) evento.get(1);
            @SuppressWarnings("unchecked")
            ArrayList<int[]> ventas = (ArrayList<int[]>) evento.get(2);
            int[] estadoAsientos = (int[]) evento.get(3);

            int asientosOcupadosEvento = 0;
            for(int estado : estadoAsientos) if(estado == 1) asientosOcupadosEvento++;
            totalOcupados += asientosOcupadosEvento;

            System.out.println("Evento: " + nombreEvento + " (ID: " + evento.get(0) + ")");
            System.out.println("  Ventas activas asociadas: " + ventas.size());
            System.out.println("  Asientos Ocupados: " + asientosOcupadosEvento + "/" + CAPACIDAD_MAXIMA);
        }
        System.out.println("Total de Asientos Ocupados (Todos los eventos): " + totalOcupados);
    }
    
    private static void actualizarAsientos() {
        System.out.println("\n--- Actualización de Estado de Asientos ---");
        
        int eventoIndex = seleccionarEvento(); 
        if (eventoIndex == -1) return; 
        
        ArrayList<Object> eventoSeleccionado = EVENTOS.get(eventoIndex);
        int[] ASES_ESTADO_EVENTO = (int[]) eventoSeleccionado.get(3);
        String nombreEvento = (String) eventoSeleccionado.get(1);
        
        System.out.println("Evento seleccionado: " + nombreEvento);
        
        System.out.print("Ingrese el ID del asiento a actualizar (0-" + (CAPACIDAD_MAXIMA - 1) + "): ");
        int idAsiento = -1;
        try {
            idAsiento = scanner.nextInt();
            scanner.nextLine();
            
            if (idAsiento < 0 || idAsiento >= CAPACIDAD_MAXIMA) {
                System.out.println("ID de asiento fuera de rango.");
                return;
            }
        } catch (InputMismatchException e) {
            System.out.println("Entrada no válida. Debe ser un número.");
            scanner.nextLine();
            return;
        }
        
        System.out.print("Nuevo estado (0: Disponible, 1: Vendido). Estado actual: " + ASES_ESTADO_EVENTO[idAsiento] + ": ");
        int nuevoEstado = -1;
        try {
            nuevoEstado = scanner.nextInt();
            scanner.nextLine();
            if (nuevoEstado != 0 && nuevoEstado != 1) throw new InputMismatchException();
        } catch (InputMismatchException e) {
            System.out.println("Estado no válido. Use 0 o 1.");
            scanner.nextLine();
            return;
        }

        if (ASES_ESTADO_EVENTO[idAsiento] == 1 && nuevoEstado == 0) {
            System.out.println("Asiento #" + idAsiento + " liberado en el evento '" + nombreEvento + "'. (Si había una venta activa asociada, esta debe anularse usando la Opción 3 para mantener la integridad total).");
        }
        
        ASES_ESTADO_EVENTO[idAsiento] = nuevoEstado;
        System.out.println("Estado del asiento #" + idAsiento + " para '" + nombreEvento + "' actualizado a " + (nuevoEstado == 1 ? "VENDIDO" : "DISPONIBLE"));
    }
}